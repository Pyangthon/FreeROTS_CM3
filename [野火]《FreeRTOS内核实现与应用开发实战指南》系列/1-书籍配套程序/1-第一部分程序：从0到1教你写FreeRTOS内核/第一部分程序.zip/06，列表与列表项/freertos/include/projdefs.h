#ifndef PROJDEFS_H
#define PROJDEFS_H

//typedef void (*TaskFunction_t)( void * );

#endif /* PROJDEFS_H */

